Test environments
-----------------

-   R version 3.5.0 (2018-04-23)
-   Platform: x86\_64-w64-mingw32/x64 (64-bit)
-   Running under: Windows &gt;= 8 x64 (build 9200)

R CMD check results
-------------------

There were no ERRORs or WARNINGs.
