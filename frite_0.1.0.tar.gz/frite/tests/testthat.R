library(testthat)
library(frite)

test_check("frite")
